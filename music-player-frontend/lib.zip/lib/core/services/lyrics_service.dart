class LyricsService {

}