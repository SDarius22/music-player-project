import 'dart:typed_data';

import 'package:music_player_frontend/core/constants.dart';
import 'package:music_player_frontend/core/entities/abstract/abstract_collection.dart';
import 'package:music_player_frontend/core/entities/abstract/base_entity.dart';
import 'package:music_player_frontend/core/entities/album.dart';
import 'package:music_player_frontend/core/entities/song.dart';
import 'package:objectbox/objectbox.dart';

@Entity()
class Artist with AbstractCollection implements BaseEntity {
  @Id()
  int id = 0;

  @Index()
  int serverId = -1;
  bool requiresSync = false;

  @Unique()
  String _name = "Unknown artist";

  @Backlink('artist')
  final _songs = ToMany<Song>();

  @Backlink('artist')
  final albums = ToMany<Album>();

  @override
  String get name => _name;

  @override
  set name(String value) => _name = value;

  Artist();

  factory Artist.fromJson(Map<String, dynamic> json) {
    Artist artist = Artist();
    artist.id = 0;
    artist.name = json['name'] ?? "Unknown Artist";
    artist.serverId = json['id'] ?? -1;
    return artist;
  }

  @override
  ToMany<Song> get songs => _songs;

  @override
  String toString() {
    return name;
  }

  @override
  Uint8List get coverArt =>
      albums.isNotEmpty ? albums.first.coverArt : Constants.logoBytes;
}
