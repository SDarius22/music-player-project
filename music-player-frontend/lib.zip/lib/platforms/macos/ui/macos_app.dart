import 'package:bot_toast/bot_toast.dart';
import 'package:flutter/material.dart';
import 'package:music_player_frontend/core/providers/abstract/abstract_app_state_provider.dart';
import 'package:music_player_frontend/core/providers/audio_provider.dart';
import 'package:music_player_frontend/core/services/abstract/abstract_music_scanner_service.dart';
import 'package:music_player_frontend/core/services/abstract/file_service.dart';
import 'package:music_player_frontend/core/services/album_service.dart';
import 'package:music_player_frontend/core/services/artist_service.dart';
import 'package:music_player_frontend/core/services/settings_service.dart';
import 'package:music_player_frontend/core/services/song_service.dart';
import 'package:music_player_frontend/core/ui/abstract_app.dart';
import 'package:music_player_frontend/core/ui/components/scaler.dart';
import 'package:music_player_frontend/core/ui/components/theme.dart';
import 'package:music_player_frontend/platforms/macos/providers/app_state_provider.dart';
import 'package:music_player_frontend/platforms/macos/services/macos_file_service.dart';
import 'package:music_player_frontend/platforms/macos/services/music_scanner_service.dart';
import 'package:music_player_frontend/platforms/macos/ui/components/macos_scaler.dart';
import 'package:music_player_frontend/platforms/macos/ui/screens/loading_screen.dart';
import 'package:provider/provider.dart';

class MacosApplication extends AbstractApp {
  const MacosApplication({super.key});

  @override
  AbstractAppStateProvider buildAppStateProvider(BuildContext context) {
    return AppStateProvider(
      context.read<AudioProvider>(),
      context.read<SettingsService>(),
    );
  }

  @override
  AbstractMusicScannerService buildMusicScannerService(BuildContext context) {
    return MacosMusicScannerService(
      context.read<SongService>(),
      context.read<ArtistService>(),
      context.read<AlbumService>(),
      context.read<AbstractFileService>(),
      context.read<SettingsService>(),
    );
  }

  @override
  AbstractFileService createFileService(BuildContext context) {
    return MacosFileService();
  }

  @override
  Scaler createScaler(BuildContext context) {
    return MacosScaler();
  }

  @override
  Widget getAppWidget(BuildContext context) {
    return MaterialApp(
      builder: BotToastInit(),
      debugShowCheckedModeBanner: false,
      checkerboardOffscreenLayers: true,
      theme: MusicPlayerTheme.getDefaultTheme(),
      home: const LoadingScreen(),
    );
  }
}
