import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:music_player_frontend/core/providers/abstract/abstract_app_state_provider.dart';
import 'package:music_player_frontend/core/providers/audio_provider.dart';
import 'package:music_player_frontend/core/ui/components/theme.dart';
import 'package:music_player_frontend/core/ui/screens/user_settings_screen.dart';
import 'package:music_player_frontend/local_libs/fluenticons/fluenticons.dart';
import 'package:music_player_frontend/platforms/android/ui/screens/add_or_export_screen.dart';
import 'package:music_player_frontend/platforms/android/ui/screens/create_or_import_screen.dart';
import 'package:provider/provider.dart';

class SettingsScreen extends AbstractUserSettingsScreen {
  static Route<void> route() {
    return PageRouteBuilder(
      settings: const RouteSettings(name: '/settings'),
      pageBuilder: (context, animation, secondaryAnimation) {
        return const SettingsScreen();
      },
    );
  }

  const SettingsScreen({super.key});

  @override
  AbstractUserSettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState
    extends AbstractUserSettingsScreenState<SettingsScreen> {
  @override
  List<Map<String, dynamic>> get settingsMap {
    var height = MediaQuery.of(context).size.height;
    var normalSize = height * 0.02;
    var smallSize = height * 0.015;

    final appState = Provider.of<AbstractAppStateProvider>(
      context,
      listen: false,
    );
    final audioProvider = Provider.of<AudioProvider>(context, listen: false);

    return [
      // Playback Speed
      {
        "title": Text(
          "Playback Speed",
          style: TextStyle(
            fontSize: normalSize,
            fontWeight: FontWeight.normal,
            color: Colors.white,
          ),
        ),
        "subtitle": Text(
          "Set the playback speed to a certain value",
          style: TextStyle(fontSize: smallSize, color: Colors.grey.shade300),
        ),
        "trailing": SizedBox(
          width: MediaQuery.of(context).size.width * 0.3,
          child: ValueListenableBuilder(
            valueListenable: audioProvider.playbackSpeedNotifier,
            builder: (context, value, child) {
              return SliderTheme(
                data: SliderThemeData(
                  trackHeight: 2,
                  thumbColor: Colors.white,
                  thumbShape: RoundSliderThumbShape(
                    enabledThumbRadius: height * 0.0075,
                  ),
                  showValueIndicator: ShowValueIndicator.onDrag,
                  activeTrackColor: MusicPlayerTheme.primaryPurple,
                  inactiveTrackColor: Colors.white,
                  valueIndicatorColor: Colors.white,
                  valueIndicatorTextStyle: TextStyle(
                    fontSize: smallSize,
                    color: Colors.black,
                  ),
                  valueIndicatorShape: const PaddleSliderValueIndicatorShape(),
                ),
                child: Slider(
                  min: 0.0,
                  max: 2.0,
                  divisions: 20,
                  label: "${value.toStringAsPrecision(2)}x",
                  mouseCursor: SystemMouseCursors.click,
                  value: value,
                  onChanged: (double value) {
                    audioProvider.setPlaybackSpeed(value);
                  },
                ),
              );
            },
          ),
        ),
      },

      // Import Playlist
      {
        "title": Text(
          "Import Playlist",
          style: TextStyle(
            fontSize: normalSize,
            fontWeight: FontWeight.normal,
            color: Colors.white,
          ),
        ),
        "subtitle": Text(
          "Import a playlist from your library",
          style: TextStyle(fontSize: smallSize, color: Colors.grey.shade300),
        ),
        "trailing": IconButton(
          onPressed: () async {
            FilePickerResult? result = await FilePicker.platform.pickFiles(
              initialDirectory: appState.appSettings.mainSongPlace,
              type: FileType.custom,
              allowedExtensions: ['m3u'],
              allowMultiple: false,
            );
            if (result != null) {
              File file = File(result.files.single.path ?? "");
              List<String> lines = file.readAsLinesSync();
              String playlistName = file.path.split("/").last.split(".").first;
              lines.removeAt(0);
              for (int i = 0; i < lines.length; i++) {
                lines[i] = lines[i].split("/").last;
              }
              appState.innerNavigatorKey.currentState?.push(
                CreateOrImportScreen.route(
                  playlistName: playlistName,
                  playlistPaths: lines,
                  import: true,
                ),
              );
            }
          },
          icon: Icon(
            FluentIcons.open,
            color: Colors.white,
            size: height * 0.03,
          ),
        ),
      },

      // Export Playlists
      {
        "title": Text(
          "Export Playlists",
          style: TextStyle(
            fontSize: normalSize,
            fontWeight: FontWeight.normal,
            color: Colors.white,
          ),
        ),
        "subtitle": Text(
          "Export playlists to your library",
          style: TextStyle(fontSize: smallSize, color: Colors.grey.shade300),
        ),
        "trailing": IconButton(
          onPressed: () {
            appState.innerNavigatorKey.currentState?.push(
              AddOrExportScreen.route(export: true),
            );
          },
          icon: Icon(
            FluentIcons.open,
            color: Colors.white,
            size: height * 0.03,
          ),
        ),
      },
    ];
  }

  @override
  EdgeInsetsGeometry buildPadding(BuildContext context) {
    var width = MediaQuery.of(context).size.width;
    var height = MediaQuery.of(context).size.height;
    return EdgeInsets.symmetric(
      horizontal: width * 0.025,
      vertical: height * 0.025,
    );
  }
}
